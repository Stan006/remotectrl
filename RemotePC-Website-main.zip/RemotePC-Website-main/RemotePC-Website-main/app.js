/* ==========================================================
   GLOBAL CONSTANTS
========================================================== */
const CONFIG = {
  REVEAL_THRESHOLD: 0.15,
  REVEAL_STAGGER: 100,
  GRID_CELL_SIZE: 40,
  TOAST_DURATION: 2200,
  COOKIE_KEY: 'remotepc_cookie_consent',
  GA_ID: 'G-2FD0X1BBMS'
};


/* ==========================================================
   DOM READY
========================================================== */
document.addEventListener('DOMContentLoaded', () => {
  initRevealObserver();
  initNav();
  initCookieConsent();
  initDownloadButtons();
  initGlowGrid();
  initCardsHover();
  initFAQ();
  initRequirementStagger();
  initSecurityScan();
  initSupportTerminal();
  initLegalTOC();
  initSystemStats();
  initMouseEffects();
});


/* ==========================================================
   REVEAL ON SCROLL (SINGLE OBSERVER)
========================================================== */
function initRevealObserver() {
  const elements = document.querySelectorAll(
    '[data-animate], .card, .feature-item, .hero-content, .req-column'
  );

  if (!elements.length) return;

  const observer = new IntersectionObserver(entries => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.classList.add('is-visible');
        }, i * CONFIG.REVEAL_STAGGER);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: CONFIG.REVEAL_THRESHOLD });

  elements.forEach(el => {
    el.classList.add('reveal-init');
    observer.observe(el);
  });
}


/* ==========================================================
   NAV TOGGLE (SINGLE SOURCE OF TRUTH)
========================================================== */
function initNav() {
  const btn = document.querySelector('.nav-toggle');
  const nav = document.getElementById('primary-nav');
  if (!btn || !nav) return;

  const setState = open => {
    nav.classList.toggle('open', open);
    btn.setAttribute('aria-expanded', String(open));
    document.body.classList.toggle('nav-open', open);
    document.body.style.overflow = open ? 'hidden' : '';
  };

  btn.addEventListener('click', () => {
    setState(!nav.classList.contains('open'));
  });

  nav.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => setState(false));
  });
}


/* ==========================================================
   COOKIE CONSENT + ANALYTICS
========================================================== */
function initCookieConsent() {
  const banner = document.getElementById('cookie-banner');
  if (!banner) return;

  const getConsent = () => {
    try { return localStorage.getItem(CONFIG.COOKIE_KEY); }
    catch { return null; }
  };

  const setConsent = val => {
    try { localStorage.setItem(CONFIG.COOKIE_KEY, val); }
    catch {}
  };

  const loadAnalytics = () => {
    if (window.__analyticsLoaded) return;
    window.__analyticsLoaded = true;

    const s = document.createElement('script');
    s.async = true;
    s.src = `https://www.googletagmanager.com/gtag/js?id=${CONFIG.GA_ID}`;
    document.head.appendChild(s);

    window.dataLayer = window.dataLayer || [];
    window.gtag = function(){ dataLayer.push(arguments); };
    gtag('js', new Date());
    gtag('config', CONFIG.GA_ID, { anonymize_ip: true });
  };

  const consent = getConsent();
  if (consent === 'all') loadAnalytics();
  if (!consent) setTimeout(() => banner.classList.add('visible'), 1500);

  banner.querySelector('#cookie-essential')?.addEventListener('click', () => {
    setConsent('essential');
    banner.classList.remove('visible');
  });

  banner.querySelector('#cookie-all')?.addEventListener('click', () => {
    setConsent('all');
    loadAnalytics();
    banner.classList.remove('visible');
  });
}


/* ==========================================================
   DOWNLOAD BUTTON EFFECTS
========================================================== */
function initDownloadButtons() {
  const buttons = document.querySelectorAll('.download-btn');
  const toast = document.getElementById('download-toast');
  if (!buttons.length || !toast) return;

  let timeout;

  const showToast = text => {
    toast.textContent = text;
    toast.classList.add('visible');
    clearTimeout(timeout);
    timeout = setTimeout(() => toast.classList.remove('visible'), CONFIG.TOAST_DURATION);
  };

  buttons.forEach(btn => {
    btn.addEventListener('click', e => {
      const r = btn.getBoundingClientRect();
      btn.style.setProperty('--ripple-x', `${e.clientX - r.left}px`);
      btn.style.setProperty('--ripple-y', `${e.clientY - r.top}px`);
      btn.classList.remove('is-pressed');
      void btn.offsetWidth;
      btn.classList.add('is-pressed');

      showToast(`Download started – ${btn.dataset.platform || btn.textContent.trim()}`);
    });
  });
}


/* ==========================================================
   GLOW GRID (SINGLE IMPLEMENTATION)
========================================================== */
function initGlowGrid() {
  const grid = document.getElementById('glow-grid');
  if (!grid) return;

  const buildGrid = () => {
    grid.innerHTML = '';
    const cols = Math.ceil(window.innerWidth / CONFIG.GRID_CELL_SIZE);
    const rows = Math.ceil(window.innerHeight / CONFIG.GRID_CELL_SIZE);
    grid.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;

    const frag = document.createDocumentFragment();
    for (let i = 0; i < cols * rows; i++) {
      frag.appendChild(document.createElement('div')).className = 'grid-cube';
    }
    grid.appendChild(frag);
  };

  buildGrid();
  window.addEventListener('resize', debounce(buildGrid, 250));
}


/* ==========================================================
   CARD HOVER EFFECTS
========================================================== */
function initCardsHover() {
  document.querySelectorAll('.card').forEach(card => {
    card.addEventListener('mousemove', e => {
      const r = card.getBoundingClientRect();
      card.style.setProperty('--x', `${e.clientX - r.left}px`);
      card.style.setProperty('--y', `${e.clientY - r.top}px`);
    });
  });
}


/* ==========================================================
   FAQ ACCORDION
========================================================== */
function initFAQ() {
  document.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.faq-item').forEach(item => {
        item.classList.remove('active');
        item.querySelector('.faq-answer')?.style.removeProperty('max-height');
      });

      const item = btn.closest('.faq-item');
      const answer = item?.querySelector('.faq-answer');
      if (!item || !answer) return;

      item.classList.add('active');
      answer.style.maxHeight = answer.scrollHeight + 'px';
    });
  });
}


/* ==========================================================
   REQUIREMENT STAGGER
========================================================== */
function initRequirementStagger() {
  const cols = document.querySelectorAll('.req-column');
  const container = document.querySelector('.requirements-dashboard');
  if (!cols.length || !container) return;

  cols.forEach(c => {
    c.style.opacity = 0;
    c.style.transform = 'translateY(20px)';
  });

  const observer = new IntersectionObserver(e => {
    if (!e[0].isIntersecting) return;
    cols.forEach((c, i) =>
      setTimeout(() => {
        c.style.opacity = 1;
        c.style.transform = 'translateY(0)';
      }, i * 150)
    );
    observer.disconnect();
  }, { threshold: 0.2 });

  observer.observe(container);
}


/* ==========================================================
   SECURITY SCAN
========================================================== */
function initSecurityScan() {
  const card = document.querySelector('.security-card');
  if (card) card.appendChild(Object.assign(document.createElement('div'), { className: 'scan-line' }));
}


/* ==========================================================
   TERMINAL TYPE EFFECT
========================================================== */
function initSupportTerminal() {
  const title = document.querySelector('.terminal-title');
  if (!title) return;

  const text = title.textContent;
  title.textContent = '';
  let i = 0;

  const type = () => {
    if (i < text.length) {
      title.textContent += text[i++];
      setTimeout(type, 100);
    }
  };

  new IntersectionObserver(e => {
    if (e[0].isIntersecting) type();
  }).observe(title);
}


/* ==========================================================
   LEGAL TOC
========================================================== */
function initLegalTOC() {
  const toc = document.querySelector('.legal-toc');
  if (!toc) return;

  const links = toc.querySelectorAll('a');
  const sections = document.querySelectorAll('.legal-content .card');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        links.forEach(l =>
          l.classList.toggle('active', l.getAttribute('href') === `#${e.target.id}`)
        );
      }
    });
  }, { rootMargin: '-20% 0px -70% 0px' });

  sections.forEach(s => observer.observe(s));
}


/* ==========================================================
   SYSTEM STATS SIMULATION
========================================================== */
function initSystemStats() {
  setInterval(() => {
    const cpu = document.getElementById('cpu-fill');
    const cpuText = document.getElementById('cpu-text');
    if (cpu && cpuText) {
      const v = Math.floor(Math.random() * 40) + 10;
      cpu.style.width = v + '%';
      cpuText.textContent = v + '%';
      cpu.classList.toggle('high-usage', v > 45);
    }
  }, 2000);
}


/* ==========================================================
   THROTTLED MOUSE EFFECTS
========================================================== */
function initMouseEffects() {
  const screen = document.querySelector('.screen-wrapper');
  const grid = document.getElementById('glow-grid');

  let ticking = false;
  window.addEventListener('mousemove', e => {
    if (ticking) return;
    ticking = true;

    requestAnimationFrame(() => {
      if (screen) {
        screen.style.transform =
          `rotateY(${(e.clientX - innerWidth / 2) / 50}deg)
           rotateX(${-(e.clientY - innerHeight / 2) / 50}deg)`;
      }

      if (grid) {
        const r = grid.getBoundingClientRect();
        const x = ((e.clientX - r.left) / r.width) * 100;
        grid.style.setProperty('--mouse-x', `${x}%`);
        grid.style.setProperty('--grid-color-dynamic', `hsl(${180 + x},80%,70%)`);
      }

      ticking = false;
    });
  });
}


/* ==========================================================
   UTIL
========================================================== */
function debounce(fn, delay) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), delay);
  };
}
